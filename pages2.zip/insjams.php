<?php 
include("conect.php");


session_start();


if(isset($_GET['jour']))      $jour=$_GET['jour'];
else      $jour="null";

if(isset($_POST['titre']))      $titre=$_POST['titre'];
else      $titre="null";

if(isset($_POST['auteur']))      $auteur=$_POST['auteur'];
else      $auteur="null";

if(isset($_POST['chant']))      $chant=$_POST['chant'];
else      $chant="off";

if(isset($_POST['piano']))      $piano=$_POST['piano'];
else      $piano="off";

if(isset($_POST['guitaire']))      $guitaire=$_POST['guitaire'];
else      $guitaire="off";

if(isset($_POST['saxophone']))      $saxophone=$_POST['saxophone'];
else      $saxophone="off";

if(isset($_POST['contrebasse']))      $contrebasse=$_POST['contrebasse'];
else      $contrebasse="off";

if(isset($_POST['batterie']))      $batterie=$_POST['batterie'];
else      $batterie="off";

echo $_SESSION['u_user'];

          $participant1=$_SESSION['u_user'];

          $participant2="null";

          $participant3="null";

          $participant4="null";

          $participant5="null";

          $participant6="null";




// On vérifie si les champs sont vides 
if(empty($jour) OR empty($titre) OR empty($auteur) OR empty($chant) OR empty($piano) OR empty($guitaire) OR empty($saxophone) OR empty($contrebasse) OR empty($batterie) OR empty($participant1) OR empty($participant2) OR empty($participant3) OR empty($participant4) OR empty($participant5) OR  empty($participant6)) 
    { 
    echo '<font color="red">Attention, aucun champs ne peut rester vide !</font>'; 
    } 

// Aucun champ n'est vide, on peut enregistrer dans la table 
else      
    { 
       // connexion à la base
$pdo = new PDO("mysql:dbname=crear;host=localhost", 'root', '');
     
    // on écrit la requête sql 
    $sql = "INSERT INTO jams(jour, auter, titre, chant, piano, guitaire, saxophone, contrebasse, batterie, participant1, participant2, participant3, participant4, participant5, participant6) VALUES ('$jour','$auteur','$titre','$chant','$piano','$guitaire','$saxophone','$contrebasse','$batterie','$participant1','$participant2','$participant3','$participant4','$participant5','$participant6')"; 
     
    // on insère les informations du formulaire dans la table 
    $pdo->exec($sql) or die('Erreur SQL !'.$sql.'<br>'.mysql_error());      




    header("refresh:3;url=index.php");
    }  

?>


<div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                
                <div class="container">
                    <div class="row">
                        <div class="section-title text-center">
                            <h3>Félicitation votre morceau a bien était ajouté</h3>
                            <p>Veuillez patientez vous allez être redirigé...</p>
                            <i class="fa fa-refresh fa-spin fa-3x fa-fw"></i>
                        </div>
                    </div>
                </div>
</div>