
 <?php
        session_start();
       
        
        if(isset($_SESSION['u_user'])){
            
        }
        else {
            header("location: log.php");
        }
                ?>
  

    <?php
   require_once 'hearder.php';
    require_once 'nav2.php';
?>
       
        <br><br><br><br>   <br><br>   
   <link href="css/ins.css" rel="stylesheet">
    <body>
    
      <form action="master.php" method="post" class="formulaire">
        <div class="text"> <h1>inscription master classe</h1></div>
        
    
  
            <div class="row">
  <div class="col-md-3"></div>
  <div class="col-md-2"><input type="text" name="nom" placeholder="nom" class="input-48"required></div>
  <div class="col-md-1"></div>
  <div class="col-md-2"><input type="text" name="prenom" placeholder="prenom" class="input-48"required></div>
  <div class="col-md-4"></div>
</div>
           
            <div class="row">
  <div class="col-md-3"></div>
  <div class="col-md-2"><input type="text" name="adresse" placeholder="adresse" class="input-48"required></div>
  <div class="col-md-1"></div>
  <div class="col-md-2"><input type="email" name="mail" placeholder="mail" class="input-100"required></div>
  <div class="col-md-4>"></div></div>
       
           
     <div class="select">
            <div class="row">
  <div class="col-md-4 col-md-offset-5"> 
<select name="instrument">
    <option value="piano">piano</option> 
    <option  value="chant">chant</option> 
    <option  value="saxophone">saxophone</option> 
    <option  value="batterie">batterie</option> 
    <option  value="guitaire">guitaire</option> 
    <option  value="contrebasse">contrebasse</option> 
</select>
                </div></div></div>
            <br>
           
             <div class="select">
            <div class="row">
  <div class="col-md-4 col-md-offset-5"> 
<select name="niveau" >
   
    <option  value="lecture">lecture grilles</option> 
    <option   value="partition">partitions</option> 
    <option  value="impro">improvitations</option> 
</select>
</div>
                 </div></div>
        
        
           <div class="row">
           <div class="ko">
  <div class="col-md-4"></div>
  <div class="col-md-2"><h4> Navette aeroport: </h4></div>
  <div class="col-md-1"><input name="navette" value= oui  type="radio"><label for="oui">oui</label></div>
  <div class="col-md-1"><input name="navette" value= non  type="radio">
<label for="non">non</label></div>
  <div class="col-md-4"></div>
</div> 
</div>
      <div class="row">
           <div class="ok">
  <div class="col-md-4"></div>
  <div class="col-md-2">  <h4> Acompagne </h4></div>
  <div class="col-md-1"><input name="acompagne" value="oui"  type="radio">
<label for="oui">oui</label></div>
  <div class="col-md-1"><input name="acompagne" value="non"  type="radio">
<label for="non">non</label></div>
  <div class="col-md-4"></div>
</div> 
</div>
<br>
 <div class="row">
  <div class="col-md-4 col-md-offset-5"><input type="submit" value="Inscription" class="btn-enviar"> </div>
          </div></p>
    
        
        </form>
    </body> 
     <br><br><br><br> <br><br><br><br> <br><br><br><br> <br><br><br><br> <br><br><br>
<?php
  require_once 'footer.php' ;
    
    ?> 