
<?php 
include 'conection.php'; 

$nom=$_POST["nom"];
$prenom=$_POST["prenom"];
$adresse=$_POST["adresse"];
$mail=$_POST["mail"];
$instrument=$_POST["instrument"];
$niveau=$_POST["niveau"];
$navette=$_POST["navette"];
$acompagne=$_POST["acompagne"];

//recibir los datos y almacenarlos en variables 
//consulta para insertar
$insertar = "INSERT INTO masterclass(nom, prenom, adresse, mail, instrument, niveau, navette, acompagne) VALUES ( '$nom', '$prenom', '$adresse', '$mail', '$instrument', '$niveau', '$navette', '$acompagne' )"; 
//ejecutar consulta


$verifier_email = mysqli_query($conexion, "SELECT * FROM masterclass WHERE mail= '$mail'");
if (mysqli_num_rows($verifier_email) > 0) {
    echo 'email enregistre';
    exit;
}



$resultado = mysqli_query($conexion, $insertar);
if (!$resultado) {
    echo 'wrong';
} else {
    header("location: master&jams.php");         
}

//cerrar conexion
mysqli_close($conexion);