<?php
        session_start();
       
        
        if(isset($_SESSION['u_user'])){
            
        }
        else {
            header("location: log.php");
        }
    

 require_once 'hearder.php';
    require_once 'nav2.php';


$jour=$_GET["jour"];


if ($jour==1)
{
    $jour1 = 'lundi';
}
if ($jour==2)
{
    $jour1 = 'mardi';
}
if ($jour==3)
{
    $jour1 = 'mercredi';
}
if ($jour==4)
{
    $jour1 = 'jeudi';
}
if ($jour==5)
{
    $jour1 = 'vendredi';
}
if ($jour==6)
{
    $jour1 = 'samedi';
}
if ($jour==7)
{
    $jour1 = 'dimanche';
}
?>



	
	
	    <link rel="stylesheet" href="css/intento1.css">

<body>
<br><br><br><br>
<form action="insjams.php?jour=<?php echo $jour1?>" method="post" class="form-register">

      
      
         <div class="row">
  <div class="col-md-4 col-md-offset-4"><h1>Jams</h1></div>
</div>
        
        <br>
 <div class="row">
<h2> <strong><?php echo $jour1;  ?></strong> </h2></div>
</div>
    
	
<div class="contenedor-inputs">
            <input type="text" name="titre" placeholder="titre" class="input-48"required>
            <input type="text" name="auteur" placeholder="Auteur" class="input-48"required>
            <div class="wrap">

<div class="row">
  <div class="col-md-2 col-md-offset-2"><input name="chant" id="chant" type="radio">
<label for="cha">Chant</label></div>
</div>
<div class="row">
  <div class="col-md-2 col-md-offset-2"><input name="piano" id="piano" type="radio">
<label for="pia">Piano</label></div>
</div>
<div class="row">
  <div class="col-md-2 col-md-offset-2"><input name="guitaire" id="guitaire" type="radio">
<label for="guita">Guitaire</label></div>
</div>
<div class="row">
  <div class="col-md-2 col-md-offset-2"><input name="saxophone" id="sax" type="radio">
<label for="s">Sax</label></div>
</div>
<div class="row">
  <div class="col-md-2 col-md-offset-2"><input name="contrebasse" id="contrebasse" type="radio">
<label for="contre">Contrebasse</label></div>
</div>
<div class="row">
  <div class="col-md-2 col-md-offset-2"><input name="batterie" id="batterie" type="radio">
<label for="batt">Batterie</label></div>
</div>
 


<br><br><br>
  <div class="row">
  <div class="col-md-2 col-md-offset-2"><input type="submit" value="Envoyer" class="btn-enviar"></div>
</div>

    </form>
</body>

     