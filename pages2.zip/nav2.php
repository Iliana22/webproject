<?php
/**
* Nav du site ...
**/
?>


    <header>
        
        <div class="contenedor">
         <h1 class="icon-music">Master classe Jazz </h1>    
         <input type="checkbox" id="menu-bar">
         <label class="icon-menu" for="menu-bar"></label>
         <nav class="menu">
             <a href="welcome.php">Acueill</a>
             <a href="master&jams.php">Master & Jams</a>
             <a href="profs.php">Professeurs</a>
             <a href="galeries.php">Galeries</a>
             <a href=""></a>
             <a href="fermer.php">Desconexion</a>
             
             
         </nav>
        </div>
    </header> 