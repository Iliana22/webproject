<?php

    require_once 'hearder.php';
    require_once 'nav.php';
?>
        <link rel="stylesheet" href="css/login.css">
    <body class="no">
        <form action="sesion1.php" method="POST">
            <h2>Login</h2>
            <input type="text" placeholder="&#128272; usuaire/user" name="user" class="input-48"required>
            <input type="password" placeholder="&#128272; mot de passe/password" name="mot" class="input-48"required>
            <input type="submit" value="Login">
            <p class="form_link">Vous n’avez pas de compte ? <a href="createaco.php">Click ici</a> </p>
        </form>
        
        
</body>