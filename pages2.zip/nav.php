<?php
/**
* Nav du site ...
**/
?>


    <header>
        
        <div class="contenedor">
         <h1 class="icon-music">Master classe Jazz </h1>    
         <input type="checkbox" id="menu-bar">
         <label class="icon-menu" for="menu-bar"></label>
         <nav class="menu">
             <a href="index.php">Accueil</a>
             <a href="master&jams.php">master&jams</a>
             <a href="professeurs.php">Professeurs</a>
             <a href="galerie.php">Galeries</a>
             <a href=""></a>
             <a href="log.php">LOGIN</a>
             
         </nav>
        </div>
    </header> 