
 <?php
        session_start();
       
        
        if(isset($_SESSION['u_user'])){
            
        }
        else {
            header("location: log.php");
        }
                ?>


<?php
 require_once 'hearder.php';
    require_once 'nav2.php';
?>



	
	<link rel="stylesheet" href="css/master&jams.css">

<body>
<br><br><br><br><br><br>
<form action="insjams.php" method="post" class="form-register">

 
 <div class="row">
  <div class="col-md-4 col-md-offset-4"><h1>Master classe</h1></div>
</div>
     <div class="equis">
      <div class="row">
  <div class="col-md-4 col-md-offset-4"><ul>
      <h2 class="hover"><a href="inscrire.php">Inscription</a> </h2></div>
          </div></div>
         <div class="row">
  <div class="col-md-4 col-md-offset-4"><h1>Jams</h1></div>
</div>
        
        <br>

<div class="equisde">
<div class="row">
  <div class="col-xs-6 col-sm-3"><h3> <strong>Lundi</strong></h3><ul>
      <li class="hover"><a href="Lundi.php?jour=1">Ajouter un morceau</a> </li>  
    </ul></div>
  <div class="col-xs-6 col-sm-3"><h3> <strong>Mardi</strong> </h3><ul>
      <li class="hover"><a href="Lundi.php?jour=2">Ajouter un morceau</a></li>  
         </ul></div>
  <div class="col-xs-6 col-sm-3"><h3> <strong>Mercredi</strong> </h3><ul>
       <li class="hover"><a href="Lundi.php?jour=3">Ajouter un morceau</a></li></ul></div>
  <div class="col-xs-6 col-sm-3"><h3> <strong>Jeudi</strong> </h3><ul>
      <li class="hover"><a href="Lundi.php?jour=4">Ajouter un morceau</a> </li>  
    </ul></div>
</div>
    </div>

	
<div class="equisde">
 <div class="row">
  <div class="col-xs-6 col-md-4"><h3> <strong>Vendredi</strong></h3><ul>
      <li class="hover"><a href="Lundi.php?jour=5">Ajouter un morceau</a> </li>  
    </ul></div>
  <div class="col-xs-6 col-md-4"><h3> <strong>Samedi</strong> </h3><ul>
      <li class="hover"><a href="Lundi.php?jour=6">Ajouter un morceau</a> </li>  
    </ul></div>
  <div class="col-xs-6 col-md-4"><h3> <strong>Dimanche</strong> </h3><ul>
      <li class="hover"><a href="Lundi.php?jour=7">Ajouter un morceau</a> </li>  
    </ul></div>
</div>   
   </div>
   

     
    <br><br> 
    
    <?php
include('databaseParam.php');
?>
<!--requete-->
<?php
 $reponse=$bdd->query('SELECT * FROM jams');
$repons=$bdd->query('SELECT * FROM jams');
$repon=$bdd->query('SELECT * FROM jams');
$repo=$bdd->query('SELECT * FROM jams');


include 'conection.php'; 
 ?>
 
<!--aficher les résultats -->
 <h1>Jams de la semaine</h1>
        <br><br> <br> <br>
<div class="row">
  <div class="col-xs-6 col-sm-3"><h3> <strong>Jour</strong></h3>
  
  <?php
while($donnees=$reponse->fetch())
{
    echo $donnees['jour'].'</br>'; } ?>
    </div>
  <div class="col-xs-6 col-sm-3"><h3> <strong>titre</strong></h3>
  
  <?php
while($donnees=$repons->fetch())
{
    echo $donnees['titre'].'</br>'; } ?>
    </div>
  <div class="col-xs-6 col-sm-3"><h3> <strong>Auteur</strong></h3>
  
  <?php
while($donnees=$repon->fetch())
{
    echo $donnees['auter'].'</br>'; } ?>
    </div>
    
  <div class="col-xs-6 col-sm-3"><h3> <strong>Propose par:</strong> </h3><?php
while($donnees=$repo->fetch())
{
    echo $donnees['participant1'].'</br>';
    
}?></div>
</div>
    
    
    
    
    
  
   </form>   
     
     
     
     
     
     
     
</body>

     <br><br><br><br><br><br>
    <?php
    require_once 'footer.php' ;
    ?>  