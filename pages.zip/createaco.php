
 <?php
    require_once 'header1.php';
    require_once 'nav.php';
?>
        <br><br><br><br>      
  <link rel="stylesheet" href="css/createaco.css">
    <body>
        <div class="texto"> <h1>Formulaire d'enregistrement</h1></div>
        <br><br><br><br>
        <form action="register.php" method="post" class="form-register">
            <h2 class="form_titre">Creer une compte</h2>
            <div class="contenedor-inputs">
            <input type="text" name="nom" placeholder="nom/name" class="input-48"required>
            <input type="text" name="prenom" placeholder="prenom/first name" class="input-48"required>
            <input type="email" name="email" placeholder="courriel/Email" class="input-100"required>
            <input type="text" name="user" placeholder="usaire/user" class="input-48"required>
            <input type="password" name="mot" placeholder="mot de passe/password" class="input-48"required>
            <input type="submit" value="créer mon compte/create acount" class="btn-enviar">
            <p class="form_link">Vous possédez déjà un compte? <a href="log.php">Click ici</a> </p>
            </div>
        </form>
    </body> 
     <br><br><br><br> 
<?php
    require_once 'footer.php' ;
    ?>     