<?php
$conexion = new mysqli("localhost", "root", "", "crear");

?>