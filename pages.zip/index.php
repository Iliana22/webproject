<?php
    require_once 'hearder.php';
    require_once 'nav.php';
?>
   
    <main>
        <section id="banner">
            <img src="img/i1.jpg" alt="">
            <div class="contenedor">
            
            <h2>Master Classe  Jazz</h2>
           
            </div>
        </section>
        <section id="Bienvenue">
           <div class="test">
       <div class="row">
  <div class="col-md-6 col-md-offset-3"><h4>la Master classe Jazz c'est un cours intensif avec un duration d'une semaine, pendant cette semaine il y aura aussi des concerts jams ouvertes au publique en general </h4></div>
</div>
            </div>
         </section>         
    
       
       <h2 class="section__title">nos prix</h2>
       <section class="courses">
           
           <div class="courses__columna">
               <img src="img/compte.png" alt="" class="courses__img">
               <div class="courses__description">
                   <h3 class="courses__title">compte</h3>
                    <h3 class="courses__title">Gratuit</h3>
                   <p class="courses__txt">la compte vous permet de s'inscrire a notre master classe ou jams!</p>
               </div>
           </div>
           <div class="courses__columna">
               <img src="img/ima.png" alt="" class="courses__img">
               <div class="courses__description">
                   <h3 class="courses__title">Master classe</h3>
                    <h3 class="courses__title">300€</h3>
                   <p class="courses__txt">la Master classe aura lieu á Nice le 19 fevrier 2017!</p>
          </div>
           </div>
           <div class="courses__columna">
               <img src="img/ja.png" alt="" class="courses__img">
               <div class="courses__description">
                   <h3 class="courses__title">Jams</h3>
                   <h3 class="courses__title">Gratuit</h3>
                   <p class="courses__txt">Tous les soires sont impros des morseaux du jazz! </p>
               </div>
           </div>
       </section>
       
       
        <section id="contenu">
           <h3>Actualités</h3>
           <div class="contenedor">
               <article>
                   <a href="professeurs.php">  <img src="img/i2.jpg" alt=""></a>
                   <h4>Professeurs</h4>
               </article>
               <article>
                   <a href="master&jams.php"> <img src="img/i3.jpg" alt=""></a>
                   <h4>Jams</h4>
               </article>
               <article>
                   <a href="galerie.php"> <img src="img/im3.png" alt=""></a>
                    <h4>Galeries</h4>
               </article>   
           </div>    
        </section>
    </main> 
    <br><br>
    <?php
    require_once 'footer.php' ;
    ?>     
   