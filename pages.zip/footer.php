 <?php
/**
* Partie Header du site
**/
?>
 <footer>
        <div class="contenedor">
            <p class="copy">Jazz &copy; 2017</p>
            <div class="social">
            <a class="icon-facebook-squared" href="https://www.facebook.com/JAZZ.MUZIC"></a>
            <a class="icon-twitter" href="https://twitter.com/Cool_Jazz_Music"></a>
            <a class="icon-instagram" href="https://www.instagram.com/_jazz_music_/"></a>
            <a class="icon-youtube" href="https://www.youtube.com/channel/UC7KZmdQxhcajZSEFLJr3gCg"></a>
            </div>
        </div>
    </footer>           
   </body>
</html>