<?php
    require_once 'hearder.php';
    require_once 'nav.php';
?>
<head>
<br><br><br><br>
<title>Galerie des photos</title>
<link rel="stylesheet" type="text/css" href="css/galeries.css"/>
<script src= "https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
		<script src="js/jquery.flexslider.js"></script>
		<script type="text/javascript" charset= "utf-8">
		$(window).load(function() {
		$('.flexslider').flexslider();
		});
		</script>
<body>

	<div class="xd"><div class="row">
  <div class="col-md-2 col-md-offset-5"><h1>Photos</h1></div>
        </div></div>
<br><br>
	<div class="row">
  <div class="col-md-6 col-md-offset-3">
<div class="flexslider">
		<ul class="slides">
			<li>
                <a href="photo2016.php"> <img src="img/flex1.jpg" alt=""></a>
				<section class="flexslider-caption">
				<p> Photos 2016</p></section>
			</li>
			<li>
                <a href="photo2015.php"><img src="img/flex2.png" alt=""></a>
				<section class="flexslider-caption">
				<p> Photos 2015</p></section>
			</li>
			<li>
                <a href="photo2014.php"><img src="img/flex3.jpg" alt=""></a>
				<section class="flexslider-caption">
				<p> Photos 2014</p></section>
			</li>
			</ul></div
			</div>
</div>  

<br><br><br><br><br>

<section class="dx"><div class="row">
  <div class="col-md-2 col-md-offset-5"><h1>Videos</h1></div>
    </div></div>
      <br><br>
	<div class="row">
  <div class="col-md-6 col-md-offset-3">
<div class="flexslider">
		<ul class="slides">
			<li>
                <a href="video2016.php"> <img src="img/flex4.png" alt=""></a>
				<section class="flexslider-caption">
				<p> Videos 2016</p></section>
			</li>
			<li>
                <a href="video2015.php"><img src="img/flex5.jpg" alt=""></a>
				<section class="flexslider-caption">
				<p> Videos 2015</p></section>
			</li>
			<li>
                <a href="video2014.php"><img src="img/flex5.png" alt=""></a>
				<section class="flexslider-caption">
				<p> Videos 2014</p></section>
			</li>
    </ul></div>
			</section>
</div>  
       
</body>
<br><br>
 <?php
    require_once 'footer.php' ;
    ?> 