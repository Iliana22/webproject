<?php
/**
* Partie Header du site
**/
?>

<!DOCTYPE html>
<html lang="es">
  <head>
     <title>Jazz</title> 
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, 
     maximum-scale=1, minimum-scale=1">    
    
     <link rel="stylesheet" href="css/fontello.css">
     <link rel="stylesheet" href="css/estilos.css">
      <link href="css/bootstrap.css" rel="stylesheet">
      <link href="css/1.css">
      <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet"> 

      
  </head>  
   <body>