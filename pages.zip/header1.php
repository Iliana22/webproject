<?php
/**
* Partie Header du site
**/
?>

<!DOCTYPE html>
<html lang="es">
  <head>
     <title>Jazz</title> 
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, 
     maximum-scale=1, minimum-scale=1">    
     <link href="css/bootstrap.css" rel="stylesheet">
     <link rel="stylesheet" href="css/fontello.css">
     <link rel="stylesheet" href="css/menu.css">
      <link rel="stylesheet" href="css/createaco.css">
     <link rel="stylesheet" href="css/estilos.css">
  
      
      
  </head>  
   <body>