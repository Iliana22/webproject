<?php
    require_once 'hearder.php';
    require_once 'nav.php';
?>
<head>
<br><br><br><br>
<title>photos2014</title>
<link rel="stylesheet" type="text/css" href="css/css4.css"/>
<body>
	<h1>Photos 2014</h1>
	 <ul class="galery">
	 <li><a href="#img1"><img src="pictures/v1.png" alt=""></a></li>
	 <li><a href="#img2"><img src="pictures/v2.png" alt=""></a></li>
	 <li><a href="#img3"><img src="pictures/v3.png" alt=""></a></li>
	 <li><a href="#img4"><img src="pictures/v4.png" alt=""></a></li>
	
	
	<div class="row">
  <div class="col-md-8 col-md-offset-2">
	 <div class="modal" id= "img1">
	 <div class="imagen"><a href="#img4">&#60;</a>
         <video controls class="img-responsive">
  <source src="video/1.mp4" type="video/mp4">
</video><a href="#img2">></a>
	 </div>
	 <a class="close" href="">X</a>
      </div></div></div>
	 
	 	 
	 	 
	 	 <div class="row">
  <div class="col-md-8 col-md-offset-2">
	 	 <div class="modal" id= "img2">
	 <div class="imagen"> <a href="#img1">&#60;</a>
	<video controls class="img-responsive">
  <source src="video/2.mp4" type="video/mp4">
</video><a href="#img3">></a>
	 </div>
	 <a class="close" href="">X</a>
      </div></div></div>
	 
	 
	 
	 <div class="row">
  <div class="col-md-8 col-md-offset-2">
	 	 <div class="modal" id= "img3"> 
	 <div class="imagen"><a href="#img2">&#60;</a>
	<video controls class="img-responsive">
  <source src="video/3.mp4" type="video/mp4">
</video><a href="#img4">></a>
	 </div>
	 <a class="close" href="">X</a>
         </div></div></div>
	 
	 
	 <div class="row">
  <div class="col-md-8 col-md-offset-2">
	 	 <div class="modal" id= "img4">	 
	 <div class="imagen"><a href="#img2">&#60;</a>
	<video controls class="img-responsive">
  <source src="video/4.mp4" type="video/mp4">
</video><a href="#img1">></a>
	 </div>
	 <a class="close" href="">X</a>
	 </div></div></div>
	 
	 
	 
</body>

