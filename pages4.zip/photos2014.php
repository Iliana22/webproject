<?php
    require_once 'hearder.php';
    require_once 'nav2.php';
?>
<head>
<br><br><br><br>
<title>photos2014</title>
<link rel="stylesheet" type="text/css" href="css/css4.css"/>
<link rel="stylesheet" href="css/master&jams.css">
<body>
	<div class="equis">
      <div class="row">
  <div class="col-md-4 col-md-offset-4"><ul>
      <h1 class="hover">Photos 2014</h1></div>
          </div></div>
	 <ul class="galery">
	 <li><a href="#img1"><img src="pictures/i1.jpg" alt=""></a></li>
	 <li><a href="#img2"><img src="pictures/i2.jpg" alt=""></a></li>
	 <li><a href="#img3"><img src="pictures/i3.jpg" alt=""></a></li>
	 <li><a href="#img4"><img src="pictures/i4.png" alt=""></a></li>
	 <li><a href="#img5"><img src="pictures/i5.jpg" alt=""></a></li>
	 <li><a href="#img6"><img src="pictures/i6.jpg" alt=""></a></li>
	 <li><a href="#img7"><img src="pictures/i7.jpg" alt=""></a></li>
	 <li><a href="#img8"><img src="pictures/i8.jpg" alt=""></a></li>
	 <li><a href="#img9"><img src="pictures/i9.jpg" alt=""></a></li>
	 <li><a href="#img10"><img src="pictures/i10.jpg" alt=""></a></li>
	 <li><a href="#img11"><img src="pictures/i11.jpg" alt=""></a></li>
	 <li><a href="#img12"><img src="pictures/i12.jpg" alt=""></a></li>
	 </ul>
	 <div class="modal" id= "img1">
	 
	 <div class="imagen">
	 <a href="#img12">&#60;</a>
	 <a href="#img2"><img src="pictures/i1.jpg" alt=""></a>
	 <a href="#img2">></a>
	 </div>
	 <a class="close" href="">X</a>
	 </div>
	 
	 	 <div class="modal" id= "img2">
		 
	 <div class="imagen">
	 <a href="#img1">&#60;</a>
	 <a href="#img3"><img src="pictures/i2.jpg" alt=""></a>
	 <a href="#img3">></a>
	 </div>
	 <a class="close" href="">X</a>
	 </div>
	 
	 	 <div class="modal" id= "img3">
		
	 <div class="imagen">
	 <a href="#img2">&#60;</a>
	 <a href="#img4"><img src="pictures/i3.jpg" alt=""></a>
	 <a href="#img4">></a>
	 </div>
	 <a class="close" href="">X</a>
	 </div>
	 
	 	 <div class="modal" id= "img4">
		 
	 <div class="imagen">
	 <a href="#img3">&#60;</a>
	 <a href="#img5"><img src="pictures/i4.png" alt=""></a>
	 <a href="#img5">></a>
	 </div>
	 <a class="close" href="">X</a>
	 </div>
	 
	  <div class="modal" id= "img5">
	 
	 <div class="imagen">
	 <a href="#img4">&#60;</a>
	 <a href="#img6"><img src="pictures/i5.jpg" alt=""></a>
	 <a href="#img6">></a>
	 </div>
	 <a class="close" href="">X</a>
	 </div>
	 
	  <div class="modal" id= "img6">
	
	 <div class="imagen">
	 <a href="#img5">&#60;</a>
	 <a href="#img7"><img src="pictures/i6.jpg" alt=""></a>
	 <a href="#img7">></a>
	 </div>
	 <a class="close" href="">X</a>
	 </div>
	 
	  <div class="modal" id= "img7">
	
	 <div class="imagen">
	 <a href="#img6">&#60;</a>
	 <a href="#img8"><img src="pictures/i7.jpg" alt=""></a>
	 <a href="#img8">></a>
	 </div>
	 <a class="close" href="">X</a>
	 </div>
	 
	  <div class="modal" id= "img8">
	
	 <div class="imagen">
	 <a href="#img7">&#60;</a>
	 <a href="#img9"><img src="pictures/i8.jpg" alt=""></a>
	 <a href="#img9">></a>
	 </div>
	 <a class="close" href="">X</a>
	 </div>
	 
	  <div class="modal" id= "img9">
	
	 <div class="imagen">
	 <a href="#img8">&#60;</a>
	 <a href="#img10"><img src="pictures/i9.jpg" alt=""></a>
	 <a href="#img10">></a>
	 </div>
	 <a class="close" href="">X</a>
	 </div>
	 
	  <div class="modal" id= "img10">
        
         <div class="imagen">
         <a href="#img9">&#60;</a>
         <a href="#img11"><img src="pictures/i10.jpg" alt=""></a>
         <a href="#img11">></a>
         </div>
         <a class="close" href="">X</a>
	 </div>
	 
	  <div class="modal" id= "img11">
     
         <div class="imagen">
         <a href="#img10">&#60;</a>
         <a href="#img12"><img src="pictures/i11.jpg" alt=""></a>
         <a href="#img12">></a>
         </div>
         <a class="close" href="">X</a>
	 </div>
	 
	  <div class="modal" id= "img12">
        
         <div class="imagen">
         <a href="#img11">&#60;</a>
         <a href="#img1"><img src="pictures/i12.jpg" alt=""></a>
         <a href="#img1">></a>
         </div>
         <a class="close" href="">X</a>
	 </div>
</body>

<br><br><br><br><br><br><br><br><br>
 <?php
    require_once 'footer.php' ;
    ?> 