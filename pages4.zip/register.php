
<?php 
include 'conection.php'; 

$nom=$_POST["nom"];
$prenom=$_POST["prenom"];
$email=$_POST["email"];
$user=$_POST["user"];
$mot=$_POST["mot"];

//recibir los datos y almacenarlos en variables 
//consulta para insertar
$insertar = "INSERT INTO users(nom, prenom, email, user, mot) VALUES ( '$nom', '$prenom', '$email', '$user', '$mot' )"; 
//ejecutar consulta

$verifier_user = mysqli_query($conexion, "SELECT * FROM USERS WHERE email= '$user'");
if (mysqli_num_rows($verifier_user) > 0) {
    echo 'user exist';
    exit;
}

$verifier_email = mysqli_query($conexion, "SELECT * FROM USERS WHERE email= '$email'");
if (mysqli_num_rows($verifier_email) > 0) {
    echo 'email enregistre';
    exit;
}



$resultado = mysqli_query($conexion, $insertar);
if (!$resultado) {
    echo 'wrong';
} else {
    header("location: log.php");         
}

//cerrar conexion
mysqli_close($conexion);