<?php
   require_once 'hearder.php';
    require_once 'nav2.php';
?>


<br><br><br><br>
<br><br><br><br>
<link rel="stylesheet" href="css/professeurs.css">

<body>
<h1>Professeurs</h1>
<br><br><br><br>
<div id="body">
  
  
  <div class="row">
  <div class="col-md-10 col-md-offset-1">
    <div class="sub">
   <div class="row">
  <div class="col-md-6"></div>
  <div class="col-md-6">
    <div class="title">
        
    </div> </div>
</div>
    <div class="info"><div class="row">
  <div class="col-md-4"><img src="pictures/Dian.jpg" alt=""></div>
     <h1>Diana Krall(chant)</h1> 
        <br><br><br><br>
        <div class="col-md-8"><p class="inf">Diana Krall est une pianiste et chanteuse de jazz canadienne. Avec plus de 14 albums Diane a travaille avec grandes personalites du jazz comme John Clayton et Jeff Hamilton,Russell Malone, Tommy LiPuma,Christian McBrid,Johnny Mandel,Elvis Costello,Tom Waits.
Son troisième disque All for You sorti en 1996, est nommé pour un Grammy Award et demeure durant soixante-dix semaines dans le classement jazz du Billboard. En 1999 elle obtient plusieurs nominations aux Grammy Awards, qui la récompensent comme Meilleure Musicienne de Jazz de l'année. 
En septembre 2001 son premier disque live : Live in Paris (en) lui permet de remporter une seconde récompense aux Grammy Awards (Meilleur disque de jazz vocal), ainsi qu'un Juno Award. En 2004 elle arrive à la première place du World Jazz Charts (qui concerne les États-Unis, l'Allemagne, la France, le Japon et la Chine).</p></div>
</div>  
    </div>
    </div>
    </div>
</div>
  
  
   <div class="row">
  <div class="col-md-10 col-md-offset-1">
    <div class="sub">
    <div class="title">
        <p class="title"></p>
    </div>
    <div class="info"><div class="row">
  <div class="col-md-4"><img src="pictures/piano.jpg" alt=""></div>
  <h1>Herbie Hancock(Piano)</h1> 
   <br><br><br><br>
  <div class="col-md-8"><p class="inf"> Herbie Hancock est un pianiste, claviériste et compositeur de jazz. Il est l'un des musiciens de jazz les plus importants et influents. Il a mêlé au jazz des éléments de soul, de rock, de funk, de disco ainsi que, parfois, quelques rythmes issus du rap.il a 39 Albums en solitude et 26 albums avec differents artistes comme Wayne Shorter,Donald Byrd et Pepper Adams Quintet,Miles Davis,Chick Corea,Ron Carter, Tony Williams et Herbie Hancock. Grandes groupes d'edition de disques comme  Warner Brothers, Blue Note Records, Columbia et Verve/Polygram ont produit ses ouvres </p></div>
</div>  
    </div>
    </div>
    </div>
</div>
   <div class="row">
  <div class="col-md-10 col-md-offset-1">
    <div class="sub">
    <div class="title">
        <p class="title"></p>
    </div>
    <div class="info"><div class="row">
  <div class="col-md-4"><img src="pictures/guitar.jfif" alt=""></div>
  <h1>George Benson(Guitaire)</h1>
   <br><br><br><br>
  <div class="col-md-8"><p class="inf">George Benson commence sa carrière comme chanteur. C'est cependant comme guitariste qu'il se fera un nom, dans les années 1960, à titre de leader ou d'accompagnateur. Sa carrière solo explose au milieu des années 1970, alors qu'il adopte un son plus commercial, mariant pop, soul et R&B. À partir des années 1990, Benson commence à renouer avec ses racines jazz. Homme des grands événements, l'Américain a célébré le 10e anniversaire du Festival en compagnie de B.B. King. En 2010, il s'est vu remettre le deuxième Prix hommage du Salon de Guitare de Montréal.</p></div>
</div>
        
    </div>
    </div>
    </div>
</div>
   <div class="row">
  <div class="col-md-10 col-md-offset-1">
    <div class="sub">
    <div class="title">
        <p class="title"></p>
    </div>
    <div class="info"><div class="row">
  <div class="col-md-4"><img src="pictures/p1.jfif" alt=""></div>
  <h1>Donny McCalsin(Sax)</h1>
   <br><br><br><br>
  <div class="col-md-8"><p class="inf">Le Californien de naissance Donny McCaslin se produit dès l'âge 12 ans au sein de la formation de son père vibraphoniste. À l'école secondaire, le saxophoniste assemble son propre groupe et joue au festival de jazz de Monterey trois fois de suite. Dans les années 1980, McCaslin obtient une bourse d'étude du Berklee College of Music, à Boston, où il fait la rencontre de musiciens comme George Garzone et Gary Burton. Ce dernier lui fait une place dans son quintette lors d'une tournée internationale. Installé à New York, le souffleur remplace son idole, Michael Brecker, au sein de Steps Ahead. À la fin des années 1990, il oeuvre au sein du collectif jazz expérimental Lan Xang. Perpetual Motion (2011) constitue sa première incursion en territoire funk. Après avoir joué sur le dernier album de David Bowie, Blackstar, McCaslin lui consacre Beyond Now (2016).</p></div>
</div>
        
    </div>
    </div>
    </div>
</div>
   <div class="row">
  <div class="col-md-10 col-md-offset-1">
    <div class="sub">
    <div class="title">
        <p class="title"></p>
    </div>
    <div class="info"><div class="row">
  <div class="col-md-4"><img src="pictures/bajo.jfif" alt=""></div>
  <h1>Eberhard Weber(Contrebasse)</h1>
   <br><br><br><br>
  <div class="col-md-8"><p class="inf"> Eberhard est un contrebassiste, bassiste et compositeur allemand de Jazz, World fusion, Jazz contemporain, Electro jazz, Chamber jazz, Post-bop. Pionnier de la contrebasse électrique avec 16 albums sous son nom. il a participé avec Gary Burton, Kate Bush, Jan Garbarek, Pat Metheny, Ralph Towner,Mal Waldron entre autres. Il marque depuis plus de quarante ans la création musicale contemporaine. Le son ECM (Edition of Contemporary Music)</p></div>
</div>
        
    </div>
    </div>
    </div>
</div>
<div class="row">
  <div class="col-md-10 col-md-offset-1">
    <div class="sub">
    <div class="title">
        <p class="title"></p>
    </div>
    <div class="info"><div class="row">
  <div class="col-md-4"><img src="pictures/bateri.jfif" alt=""></div>
  <h1>Roy Haynes(Batterie)</h1>
  <br><br><br><br>
  <div class="col-md-8"><p class="inf">Roy Haynes est un batteur américain.Décoré de l’ordre des Arts et des Lettres en 2009, il a joué comme sideman avec de nombreux musiciens, Louis Armstrong, Billie Holiday, Lester Young, Bud Powell, Miles Davis, Charlie Parker, Dizzy Gillespie Sarah Vaughan, Thelonious Monk, Eric Dolphy, Stan Getz, Lennie Tristano, Sonny Rollins, John Coltrane, Gary Burton, Chick Corea, Pat Metheny, Michel Petrucciani, McCoy Tyner, Dave Holland, John Patitucci, Danilo Perez, Roy Hargrove, Nicholas Payton, Kenny Garrett, Art Pepper, en plus de 40 albums.</p></div>
</div>
        
    </div>
    </div>
    </div>
</div>
</div>
</body>
<br><br><br>

<?php
  require_once 'footer.php' ;
    
    ?> 