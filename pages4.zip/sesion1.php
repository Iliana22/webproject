<?php

session_start();

$user=$_POST['user'];
$contrasena=$_POST['mot'];

include("conect.php");

$proceso = $conexion->query("SELECT * FROM users WHERE user='$user' AND mot= '$contrasena'");

if($resultado = mysqli_fetch_array($proceso)){
    $_SESSION['u_user']=$user;
    header("location: welcome.php");
    
}
else {
    header("location: log.php");
    
}


?>
  
